<?php
	echo "SCreativ " . date("Y")
?>