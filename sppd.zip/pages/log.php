<!DOCTYPE html>
<html>
<head>
	<title>Log Version Program</title>
	<style type="text/css">
	body{
		font-family: candara ; 
		font-size: 14px ; 
	}
	</style>
</head>
<body>
	<h3>Log Version Program</h3>
	<b>Version : 1.0.00</b>
	<small style="font-size:11px">Editor : Mirza Ramadhany (screativ) , 30 Juni 2014 09:00</small>
	<ol>  
		<li>
			Initial Release
		</li>   
	</ol>
</body>